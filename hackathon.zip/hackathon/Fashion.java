public class Fashion {

	protected String aesthetic = "";
	protected String cpalette = "";
	protected int decades = 0000;
	protected String brand = "";
	protected String podcasts = "";
	protected String notes = "System notes: \n";

	public Fashion(){
	}

	public Fashion(String inaesthetic,String incpalette,int indecades,String inbrand,String inpodcasts){

		setAesthetic(inaesthetic);
		setCpalette(incpalette);
		setDecade(indecades);
		setBrand(inbrand);
		setPodcast(inpodcasts);

	}

	public  void setAesthetic(String in){

		aesthetic = in.toUpperCase();
	}

	public  String getAesthetic(){

		return aesthetic;

	}

	public  void setPodcast(String in){

	}

	public  String getPodcasts(){

		return podcasts;

	}

	public  void setCpalette(String in){

		cpalette = in.toUpperCase();
	}

	public  String getCpalette(){

		return cpalette;
	}

	public  void setDecade(int in){

	decades = in;


	}
	public  int getDecade(){
		return decades;
	}


	public  void setBrand(String in){

		brand = in.toUpperCase();
	}

	public  String getBrand(){
		
		return brand;
	}




	public void stats(){
		System.out.println("Searching aesthetic: " + aesthetic);
		System.out.println("Searching color palettes: " + cpalette);
		System.out.println("Searching brands: " + brand);
		System.out.println("Searching decades: " + decades);
		System.out.println("Searching podcasts: " + podcasts);
		System.out.println(notes);


	}






}
