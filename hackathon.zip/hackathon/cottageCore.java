public class cottageCore extends Fashion {

	public cottageCore(String inaesthetic,String incpalette,int indecades,String inbrands,String inpodcasts)
	{
		super(inaesthetic, incpalette, indecades, inbrands, inpodcasts);
	}



	public void stats()
	{
		System.out.println("Searching aesthetic: " + aesthetic);
		System.out.println("Searching color palettes: " + cpalette);
		System.out.println("Searching brands: " + brand);
		System.out.println("Searching decades: " + decades);
		System.out.println("Searching podcasts: " + podcasts);
		System.out.println(notes);
	}


}
