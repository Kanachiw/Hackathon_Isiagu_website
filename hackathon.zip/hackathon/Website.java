import java.util.*;
import java.util.Scanner;
import java.io.*;

public class Website{


	public static void main(String[] args) throws Exception{

		ArrayList<Fashion> fashionList = new ArrayList<Fashion>();

		Scanner input = new Scanner(System.in);
		System.out.print("What is the filename?: ");
		String db = input.next();

	  Scanner DBread = new Scanner(new File(db));

		while (DBread.hasNext()){
			System.out.print("What are you looking for? (Fashion Aesthetic): ");
			String FC = DBread.next();

			System.out.println(FC);

			if (FC.equals("Streetwear")) {

				String inaesthetic = "Streetwear";
				String incpalette = DBread.next();
				int indecades = DBread.nextInt();
				String inbrands = DBread.next();
				String inpodcasts = DBread.next();





				Fashion streetwear = new Streetwear(inaesthetic,incpalette,indecades,inbrands,inpodcasts);


				fashionList.add(streetwear);
			}
			else	if (FC.equals("Luxury")) {

				String inaesthetic = "Luxury";
				String incpalette = DBread.next();
				int indecades = DBread.nextInt();
				String inbrands = DBread.next();
				String inpodcasts = DBread.next();


				Fashion luxury = new Luxury(inaesthetic,incpalette,indecades,inbrands,inpodcasts);




				fashionList.add(luxury);
			}
			else if (FC.equals("CottageCore")) {

				String inaesthetic = "CottageCore";
				String incpalette = DBread.next();
				int indecades = DBread.nextInt();
				String inbrands = DBread.next();
				String inpodcasts = DBread.next();



				Fashion cottageCore = new cottageCore(inaesthetic,incpalette,indecades,inbrands,inpodcasts);



				fashionList.add(cottageCore);
			}
			else {
				System.out.println("Wrong input type");
			}

		}

		// show stats
		System.out.println("What aesthetic would you like to see? Streetwear, Luxury or Cottage Core)");
		String search = input.next();

		int count = 0;
		for (Fashion fashion : fashionList) {
			String fashionClass = fashion.getAesthetic();

			if (search.equals(fashionClass)) {
				fashion.stats();

				// increment count
				count++;
			}
		 }
		 System.out.println( count + " aesthetics of the " + search + " class have been found and returned by your search");


	}



}
